/* Reveal and pause lightweight section-bridge art without touching scroll position. */
(() => {
  const art = [...document.querySelectorAll('.section-bridge__art')];
  if (!art.length) return;

  const root = document.documentElement;
  const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  const setVisible = element => element.classList.add('is-visible', 'is-in-view');
  const endMarkers = [...document.querySelectorAll('[data-bridge-end]')];
  const hasObserver = 'IntersectionObserver' in window;

  if (!hasObserver) {
    art.forEach(setVisible);
    endMarkers.forEach(marker => marker.parentElement?.classList.add('is-bridge-ending'));
    return;
  }

  // Pinned chapters keep their outgoing arc hidden until the real section boundary enters view.
  if (endMarkers.length) root.classList.add('has-section-bridge-end-observer');
  const endObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const section = entry.target.parentElement;
      if (section) section.classList.toggle('is-bridge-ending', entry.isIntersecting);
    });
  }, { threshold: 0 });
  endMarkers.forEach(marker => endObserver.observe(marker));

  if (reduced) {
    art.forEach(setVisible);
    return;
  }

  root.classList.add('has-section-bridge-observer');
  const headerBottom = document.querySelector('.header')?.getBoundingClientRect().bottom ?? 0;
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible', 'is-in-view');
      } else {
        entry.target.classList.remove('is-in-view');
      }
    });
  }, { threshold: 0.01, rootMargin: `-${Math.ceil(headerBottom)}px 0px -4% 0px` });

  art.forEach(element => observer.observe(element));
})();
