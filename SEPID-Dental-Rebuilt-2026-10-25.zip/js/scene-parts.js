import * as THREE from '../vendor/three.module.js';

export class ToothModel extends THREE.Group {
  static async create(config, signal) {
    const response = await fetch(new URL('../assets/tooth.bin', import.meta.url), { signal });
    if (!response.ok) throw new Error(`Tooth asset HTTP ${response.status}`);
    const bytes = await response.arrayBuffer();
    const header = new DataView(bytes);
    if (header.getUint32(0, true) !== 0x48544f54 || header.getUint32(4, true) !== 1) {
      throw new Error('Unsupported tooth geometry');
    }
    const vertexCount = header.getUint32(8, true);
    const indexCount = header.getUint32(12, true);
    if (bytes.byteLength !== 16 + vertexCount * 12 + indexCount * 4) throw new Error('Invalid mesh length');
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(bytes, 16, vertexCount * 3), 3));
    geometry.setIndex(new THREE.BufferAttribute(new Uint32Array(bytes, 16 + vertexCount * 12, indexCount), 1));
    const normalResponse = await fetch(new URL('../assets/tooth-normals.bin', import.meta.url), { signal });
    if (!normalResponse.ok) throw new Error('Could not load enamel normals');
    const normalBytes = await normalResponse.arrayBuffer();
    if (normalBytes.byteLength !== vertexCount * 12) throw new Error('Invalid normal data');
    geometry.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(normalBytes), 3));
    geometry.computeBoundingSphere();
    const model = new ToothModel();
    const material = new THREE.MeshPhysicalMaterial({
      color: config.enamelColor,
      metalness: 0,
      roughness: config.toothRoughness,
      clearcoat: config.highlightIntensity,
      clearcoatRoughness: 0.04,
      ior: 1.46,
      reflectivity: 0.5,
      transmission: config.translucency,
      thickness: 0.25,
      attenuationColor: new THREE.Color('#f8fbff'),
      attenuationDistance: 2.6,
      envMapIntensity: 1.15,
      specularIntensity: 1.0
    });
    // Keep the large white softbox highlights without flattening the enamel
    // with excessive diffuse environment fill. Direct light still defines volume.
    material.onBeforeCompile = shader => {
      shader.fragmentShader = shader.fragmentShader.replace('#include <lights_fragment_maps>',
        THREE.ShaderChunk.lights_fragment_maps.replace(
          'iblIrradiance += getIBLIrradiance( geometryNormal );',
          'iblIrradiance += getIBLIrradiance( geometryNormal ) * 0.52;'
        ));
    };
    model.mesh = new THREE.Mesh(geometry, material);
    model.mesh.castShadow = true;
    model.mesh.receiveShadow = false;
    model.add(model.mesh);
    model.position.fromArray(config.toothPosition);
    model.rotation.fromArray([...config.toothRotation, 'XYZ']);
    model.scale.setScalar(config.toothScale);
    return model;
  }

  update(time, config, still) {
    // No perpetual spin: a sub-pixel-scale vertical float only.
    this.position.y = config.toothPosition[1] + (still ? 0 : Math.sin(time * 0.52) * config.floatAmplitude);
  }
}

export class Platform extends THREE.Group {
  static create(config, mobile = false) {
    return new Platform(config, mobile);
  }

  constructor(config, mobile = false) {
    super();
    this.config = config;
    const r = config.platformRadius;
    const h = config.platformHeight;
    const bevel = Math.min(.075, h * .22);
    const radialSegments = mobile ? 144 : 224;
    const profile = [new THREE.Vector2(0, -h), new THREE.Vector2(r - bevel, -h)];
    for (let i = 0; i <= 10; i++) {
      const a = -Math.PI / 2 + i / 10 * Math.PI / 2;
      profile.push(new THREE.Vector2(r - bevel + Math.cos(a) * bevel, -h + bevel + Math.sin(a) * bevel));
    }
    profile.push(new THREE.Vector2(r, -bevel));
    for (let i = 0; i <= 10; i++) {
      const a = i / 10 * Math.PI / 2;
      profile.push(new THREE.Vector2(r - bevel + Math.cos(a) * bevel, -bevel + Math.sin(a) * bevel));
    }
    profile.push(new THREE.Vector2(0, 0));

    const bodyGeometry = new THREE.LatheGeometry(profile, radialSegments);
    bodyGeometry.computeVertexNormals();
    this.edgeMaterial = new THREE.MeshPhysicalMaterial({
      color: config.platformColor,
      metalness: .36,
      roughness: .24,
      clearcoat: .96,
      clearcoatRoughness: .12,
      ior: 1.48,
      reflectivity: .72,
      envMapIntensity: 1.42,
      specularIntensity: .96
    });
    this.body = new THREE.Mesh(bodyGeometry, this.edgeMaterial);
    this.body.castShadow = true;
    this.body.receiveShadow = true;
    this.add(this.body);

    // A deep, polished navy top with controlled studio reflections.
    const topGeometry = new THREE.CircleGeometry(r - bevel - .006, radialSegments);
    this.topMaterial = new THREE.MeshPhysicalMaterial({
      color: '#174775',
      metalness: .24,
      roughness: .18,
      clearcoat: 1,
      clearcoatRoughness: .09,
      ior: 1.48,
      reflectivity: .8,
      envMapIntensity: 1.8,
      specularIntensity: 1
    });
    this.top = new THREE.Mesh(topGeometry, this.topMaterial);
    this.top.rotation.x = -Math.PI / 2;
    this.top.position.y = .002;
    this.top.receiveShadow = true;
    this.add(this.top);

    this.goldRimMaterial = new THREE.MeshPhysicalMaterial({
      color: '#D6B15E', metalness: .82, roughness: .2,
      clearcoat: .98, clearcoatRoughness: .07,
      envMapIntensity: 1.35, specularIntensity: 1,
      emissive: '#523813', emissiveIntensity: .055
    });
    this.goldRim = new THREE.Mesh(
      new THREE.TorusGeometry(r - bevel * .36, .0065, 10, radialSegments),
      this.goldRimMaterial
    );
    this.goldRim.rotation.x = -Math.PI / 2;
    this.goldRim.position.y = -bevel * .22;
    this.goldRim.castShadow = false;
    this.add(this.goldRim);

    // Fine, branching metallic veins follow the curved front wall instead of reading as straight stripes.
    this.veinMaterial = new THREE.MeshPhysicalMaterial({
      color: '#D6B15E', metalness: .78, roughness: .25,
      clearcoat: .95, clearcoatRoughness: .1,
      envMapIntensity: 1.35, specularIntensity: .98,
      emissive: '#63471A', emissiveIntensity: .045
    });
    this.veinHighlightMaterial = new THREE.MeshPhysicalMaterial({
      color: '#F4D88D', metalness: .72, roughness: .22,
      clearcoat: .98, clearcoatRoughness: .08,
      envMapIntensity: 1.4, specularIntensity: .98
    });
    this.veins = [];
    const mainVeinGeometry = [];
    const highlightVeinGeometry = [];
    const addVein = (path, thickness = .007, highlight = false) => {
      const curve = new THREE.CatmullRomCurve3(path.map(([angle, y]) => {
        const radius = r + .0045;
        return new THREE.Vector3(Math.sin(angle) * radius, y, Math.cos(angle) * radius);
      }), false, 'centripetal', .5);
      const geometry = new THREE.TubeGeometry(curve, Math.max(24, path.length * 12), thickness, 7, false);
      (highlight ? highlightVeinGeometry : mainVeinGeometry).push(geometry);
      this.veins.push({ path, thickness, highlight });
    };

    // Irregular diagonal fissures with varied lengths, thicknesses, and branching rather than parallel stripes.
    addVein([[-1.24,-.24],[-1.02,-.226],[-.84,-.195],[-.67,-.205],[-.51,-.145],[-.33,-.163],[-.15,-.112],[.06,-.15],[.24,-.101],[.43,-.13],[.62,-.085],[.81,-.12],[1.02,-.095],[1.2,-.16]], .0082);
    addVein([[-1.17,-.115],[-.99,-.145],[-.82,-.112],[-.66,-.153],[-.48,-.13],[-.34,-.183],[-.18,-.222],[-.02,-.184],[.12,-.205]], .0065);
    addVein([[.18,-.264],[.36,-.24],[.48,-.194],[.65,-.166],[.77,-.119],[.93,-.092],[1.13,-.116]], .0074);
    addVein([[-1.13,-.268],[-.94,-.252],[-.76,-.215],[-.59,-.229],[-.43,-.246],[-.25,-.202],[-.08,-.222]], .0059);
    // Delicate offshoots split away from the main mineral seams at nonuniform angles.
    addVein([[-.67,-.205],[-.72,-.166],[-.81,-.135],[-.85,-.101]], .0045, true);
    addVein([[-.51,-.145],[-.46,-.112],[-.39,-.09],[-.29,-.083]], .0042);
    addVein([[-.18,-.222],[-.13,-.183],[-.08,-.151],[.02,-.132]], .0045, true);
    addVein([[.36,-.24],[.43,-.214],[.50,-.183],[.54,-.148]], .0042);
    addVein([[.65,-.166],[.70,-.202],[.79,-.227],[.86,-.251]], .0045, true);
    addVein([[.93,-.092],[1.00,-.125],[1.10,-.147]], .004);
    addVein([[-.99,-.145],[-1.06,-.185],[-1.16,-.21]], .0042, true);

    // Join each finish into one buffer mesh, keeping the fine mineral detail inexpensive to draw on phones.
    const mergeTubeGeometries = geometries => {
      const vertexCount = geometries.reduce((sum, g) => sum + g.attributes.position.count, 0);
      const indexCount = geometries.reduce((sum, g) => sum + g.index.count, 0);
      const positions = new Float32Array(vertexCount * 3);
      const normals = new Float32Array(vertexCount * 3);
      const uvs = new Float32Array(vertexCount * 2);
      const indices = new Uint16Array(indexCount);
      let vertexOffset = 0;
      let indexOffset = 0;
      geometries.forEach(geometry => {
        const count = geometry.attributes.position.count;
        positions.set(geometry.attributes.position.array, vertexOffset * 3);
        normals.set(geometry.attributes.normal.array, vertexOffset * 3);
        uvs.set(geometry.attributes.uv.array, vertexOffset * 2);
        for (let i = 0; i < geometry.index.count; i++) indices[indexOffset + i] = geometry.index.array[i] + vertexOffset;
        vertexOffset += count;
        indexOffset += geometry.index.count;
        geometry.dispose();
      });
      const merged = new THREE.BufferGeometry();
      merged.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      merged.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
      merged.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
      merged.setIndex(new THREE.BufferAttribute(indices, 1));
      merged.computeBoundingSphere();
      return merged;
    };
    this.veinMeshes = [];
    [[mainVeinGeometry, this.veinMaterial], [highlightVeinGeometry, this.veinHighlightMaterial]].forEach(([geometries, material]) => {
      if (!geometries.length) return;
      const mesh = new THREE.Mesh(mergeTubeGeometries(geometries), material);
      mesh.castShadow = false;
      mesh.receiveShadow = false;
      mesh.renderOrder = 2;
      this.veinMeshes.push(mesh);
      this.add(mesh);
    });

    // Soft blue halo under the disk, restrained to blend with the existing ice-white hero background.
    this.aura = new THREE.Mesh(
      new THREE.PlaneGeometry(r * 3.1, r * 3.1),
      new THREE.ShaderMaterial({
        uniforms: { uColor: { value: new THREE.Color('#7DB6E5') } },
        vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
        fragmentShader: `
          uniform vec3 uColor;
          varying vec2 vUv;
          void main() {
            float radius = length((vUv - vec2(.5)) * 2.);
            float band = exp(-pow((radius - .73) / .14, 2.));
            float fade = 1. - smoothstep(.84, 1., radius);
            gl_FragColor = vec4(uColor, band * fade * .075);
            #include <colorspace_fragment>
          }
        `,
        transparent: true, depthTest: true, depthWrite: false,
        side: THREE.DoubleSide, toneMapped: false
      })
    );
    this.aura.rotation.x = -Math.PI / 2;
    this.aura.position.y = -h - .006;
    this.aura.renderOrder = 1;
    this.add(this.aura);

    this.position.y = config.platformTop;
    this.scale.setScalar(config.platformScale);

    // Soft real contact shadow remains confined to the pedestal footprint.
    this.ground = new THREE.Mesh(
      new THREE.PlaneGeometry(12, 12),
      new THREE.ShadowMaterial({ color: '#354D69', opacity: .2, depthWrite: false })
    );
    this.ground.material.onBeforeCompile = shader => {
      shader.vertexShader = 'varying vec2 vGround;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvGround = position.xy;');
      shader.fragmentShader = 'varying vec2 vGround;\n' + shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace('#include <tonemapping_fragment>', 'gl_FragColor.a *= 1.0 - smoothstep(2.1, 3.0, length(vGround));\n#include <tonemapping_fragment>');
    };
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.position.y = -h - .012;
    this.ground.receiveShadow = true;
    this.ground.renderOrder = -1;
    this.add(this.ground);

    this.setMobile(mobile);
  }

  setMobile(mobile) {
    this.mobile = mobile;
  }
}

export class Lighting {
  constructor(scene, renderer, config) {
    this.resources = [];
    const key = new THREE.DirectionalLight('#ffffff', config.keyLightIntensity);
    key.position.set(-5.5, 3.8, 4.2);
    key.castShadow = true;
    key.shadow.mapSize.set(config.shadowMapSize, config.shadowMapSize);
    Object.assign(key.shadow.camera, { left: -3.5, right: 3.5, top: 3.5, bottom: -3.5, near: .5, far: 18 });
    key.shadow.normalBias = .025;
    key.shadow.bias = -.00015;
    key.shadow.intensity = .58;
    key.shadow.radius = 9;
    key.shadow.blurSamples = 12;
    scene.add(key);
    this.key = key;
    const fill = new THREE.DirectionalLight('#ebf3ff', config.fillLightIntensity);
    fill.position.set(4, 2, 3);
    scene.add(fill);
    // Broad frontal bounce provides a subtle neutral blue-white reflection under the crown.
    const bounce = new THREE.DirectionalLight('#eef4ff', .08);
    bounce.position.set(0, -1.8, 6);
    scene.add(bounce);
    scene.add(new THREE.HemisphereLight('#f4f8ff', '#778395', config.ambientIntensity));

    // A local, procedurally constructed studio environment: broad softboxes.
    const studio = new THREE.Scene();
    studio.background = new THREE.Color('#353c48');
    const card = (position, scale, intensity) => {
      const material = new THREE.MeshBasicMaterial({ color: new THREE.Color().setScalar(intensity), side: THREE.DoubleSide });
      const geometry = new THREE.PlaneGeometry(...scale);
      const plane = new THREE.Mesh(geometry, material);
      plane.position.set(...position);
      plane.lookAt(0, 0, 0);
      studio.add(plane);
      this.resources.push(material, geometry);
    };
    card([-5, 2.8, 7], [4.0, 5.2], 18.0);
    card([4.5, 1.2, 5], [1.5, 4.6], 7.0);
    card([-1, 6, 3], [7, 1.8], 9.0);
    const generator = new THREE.PMREMGenerator(renderer);
    this.environment = generator.fromScene(studio, 0, .1, 30);
    scene.environment = this.environment.texture;
    generator.dispose();
    this.resources.forEach(resource => resource.dispose());
    this.resources = [];
  }

  dispose() {
    this.environment.dispose();
    this.key.shadow.dispose();
  }
}

export class Camera extends THREE.PerspectiveCamera {
  constructor(config) {
    super(config.cameraFov, 1, .1, 50);
    this.config = config;
    this.target = new THREE.Vector3(...config.cameraTarget);
    this.baseDistance = config.cameraDistance;
    this.pointer = new THREE.Vector2();
    this.goal = new THREE.Vector2();
    this.position.set(0, config.cameraHeight, this.baseDistance);
    this.lookAt(this.target);
  }

  resize(width, height) {
    this.aspect = width / Math.max(1, height);
    // Fit both the pedestal and the full orbital envelope, including on phones.
    const halfAngle = Math.tan(THREE.MathUtils.degToRad(this.fov * .5));
    const horizontalFit = 2.78 / (halfAngle * this.aspect);
    this.baseDistance = Math.max(this.config.cameraDistance, horizontalFit);
    this.updateProjectionMatrix();
  }

  update(dt, still) {
    if (still) this.goal.set(0, 0);
    this.pointer.lerp(this.goal, 1-Math.exp(-dt*4));
    const strength = this.config.interactionStrength;
    this.position.set(this.pointer.x * strength, this.config.cameraHeight + this.pointer.y * strength, this.baseDistance);
    this.lookAt(this.target);
  }
}

export function createBackdrop(config) {
  const background = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(config.backgroundColor) } },
    vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,.9999,1.);}`,
    fragmentShader: `
      uniform vec3 uColor;
      varying vec2 vUv;
      void main(){
        float center=exp(-length((vUv-vec2(.28,.70))*vec2(1.6,1.2))*1.2);
        vec3 color=uColor*mix(.72,1.18,center);
        gl_FragColor=vec4(color,1.);
        #include <colorspace_fragment>
      }`,
    depthWrite: false, toneMapped: false
  }));
  background.frustumCulled=false;
  background.renderOrder=-10;
  return background;
}
