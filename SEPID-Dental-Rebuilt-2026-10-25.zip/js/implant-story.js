/* Pinned, three-chapter implant film. A gesture advances/reverses one complete chapter. */
const FORWARD_VIDEO = 'assets/implant-story.mp4';
const REVERSE_VIDEO = 'assets/implant-story-reverse.mp4';
const CHAPTER_BOUNDS = [0, 3.1, 6.7];
const CHAPTERS = [
  { title: 'بازشدن ایمپلنت', copy: 'اجزای ایمپلنت از هم جدا می‌شوند و ساختار آن نمایان می‌شود.' },
  { title: 'ورود پیچ به فک', copy: 'پایهٔ تیتانیومی با چرخش در جایگاه خود داخل استخوان فک قرار می‌گیرد.' },
  { title: 'قرارگیری تاج', copy: 'تاج دندان پایین می‌آید و روی پایه می‌نشیند.' }
];
const fa = value => String(value).replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
const film = document.querySelector('[data-implant-film]');

if (film) {
  const root = document.documentElement;
  const video = film.querySelector('[data-video]');
  const reverse = film.querySelector('[data-reverse-video]');
  const progress = film.querySelector('[data-progress]');
  const progressParts = [...progress.children];
  const markers = [...film.querySelectorAll('.implant-steps li')];
  const sparkLayer = film.querySelector('[data-sparks]');
  const ui = {
    number: film.querySelector('[data-number]'),
    heading: film.querySelector('[data-heading]'),
    copy: film.querySelector('[data-copy]'),
    time: film.querySelector('[data-time]'),
    hint: film.querySelector('[data-hint]'),
    replay: film.querySelector('[data-replay]'),
    fallback: film.querySelector('[data-fallback]')
  };

  // Forward and reverse sources share the exact 24 fps timeline. Both are stacked in the same viewport.
  video.src = FORWARD_VIDEO;
  reverse.src = REVERSE_VIDEO;
  reverse.muted = true;
  reverse.playsInline = true;
  reverse.preload = 'auto';
  reverse.setAttribute('aria-hidden', 'true');
  reverse.tabIndex = -1;
  video.classList.add('is-visible');
  reverse.classList.remove('is-visible');

  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const duration = () => Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 9.54;
  const endTime = () => Math.max(CHAPTER_BOUNDS[2], duration() - 1 / 24);
  const boundary = index => index === 3 ? endTime() : CHAPTER_BOUNDS[index];

  let active = false;
  let completed = false;
  let completedOnce = false;
  let startAfterEntry = false;
  let bypassStoryTarget = null;
  let everStarted = false;
  let lockY = 0;
  let nextSectionY = null;
  let previousSectionY = null;
  let maxDocumentScrollY = 0;
  let stage = 0;                 // settled chapter boundary, 0..3
  let segment = null;            // { dir, from, to, media, start, end }
  let queue = 0;
  let segmentToken = 0;
  let frameRequest = 0;
  let scrollDirection = 1;
  let lastScrollY = window.scrollY;
  let gesture = null;
  let gestureTimer = 0;
  let touchStartY = null;
  let scrollTween = null;

  const setTime = seconds => {
    const safe = Math.max(0, seconds);
    ui.time.textContent = `${fa(Math.floor(safe / 60)).padStart(2, '۰')}:${fa(Math.floor(safe % 60)).padStart(2, '۰')}`;
  };
  function segmentProgress() {
    if (!segment) return 0;
    const ratio = clamp(Math.abs(segment.media.currentTime - segment.start) / Math.max(.001, Math.abs(segment.end - segment.start)), 0, 1);
    return segment.dir > 0 ? ratio : 1 - ratio;
  }

  function waitForEvent(media, name, timeout = 1200) {
    if (name === 'loadedmetadata' && media.readyState >= 1) return Promise.resolve();
    if (name === 'loadeddata' && media.readyState >= 2) return Promise.resolve();
    if (name === 'seeked' && !media.seeking) return Promise.resolve();
    return new Promise(resolve => {
      let finished = false;
      const done = () => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        media.removeEventListener(name, done);
        media.removeEventListener('error', done);
        resolve();
      };
      const timer = setTimeout(done, timeout);
      media.addEventListener(name, done, { once: true });
      media.addEventListener('error', done, { once: true });
    });
  }

  function waitForPresentedFrame(media) {
    return new Promise(resolve => {
      let finished = false;
      let videoFrameId = 0;
      let timeoutId = 0;
      const done = () => {
        if (finished) return;
        finished = true;
        cancelAnimationFrame(raf1);
        cancelAnimationFrame(raf2);
        clearTimeout(timeoutId);
        if (videoFrameId && media.cancelVideoFrameCallback) media.cancelVideoFrameCallback(videoFrameId);
        resolve();
      };
      const raf1 = requestAnimationFrame(() => { raf2 = requestAnimationFrame(done); });
      let raf2 = 0;
      timeoutId = setTimeout(done, 100);
      if (media.requestVideoFrameCallback) videoFrameId = media.requestVideoFrameCallback(done);
    });
  }

  async function prepareMedia(media, time) {
    if (media.readyState < 1) await waitForEvent(media, 'loadedmetadata');
    if (media.error) throw new Error('Video metadata could not be loaded');
    if (Math.abs(media.currentTime - time) > .015) {
      media.currentTime = time;
      if (media.seeking) await waitForEvent(media, 'seeked', 800);
    }
    if (media.readyState < 2) await waitForEvent(media, 'loadeddata', 800);
    await waitForPresentedFrame(media);
  }

  function renderUI({ animate = false } = {}) {
    const visibleStage = segment ? segment.chapter : (stage || 1);
    const settledStage = segment ? segment.from : stage;
    const movingPart = segment ? visibleStage : 0;
    const chapter = CHAPTERS[clamp(visibleStage - 1, 0, 2)];
    ui.number.textContent = `حرکت ${fa(String(visibleStage).padStart(2, '0'))} / ۰۳`;
    ui.heading.textContent = chapter.title;
    ui.copy.textContent = chapter.copy;
    markers.forEach((item, index) => {
      const number = index + 1;
      item.classList.toggle('done', number <= settledStage);
      item.classList.toggle('current', number === visibleStage);
      if (number === visibleStage) item.setAttribute('aria-current', 'step');
      else item.removeAttribute('aria-current');
    });
    progressParts.forEach((item, index) => {
      const done = index + 1 <= settledStage;
      const current = Boolean(segment) && index + 1 === movingPart;
      item.classList.toggle('done', done);
      item.classList.toggle('current', current);
      item.style.setProperty('--step-progress', done ? '1' : current ? String(segmentProgress()) : '0');
    });
    progress.setAttribute('aria-valuenow', String(settledStage));
    progress.setAttribute('aria-valuetext', segment
      ? `در حال اجرای حرکت ${fa(visibleStage)} از سه`
      : `حرکت ${fa(visibleStage)} از سه`);
    if (animate) {
      const card = film.querySelector('.implant-chapter');
      card.classList.remove('is-changing');
      void card.offsetWidth;
      card.classList.add('is-changing');
    }
  }

  function setHint() {
    if (!everStarted) {
      ui.hint.textContent = 'برای حرکت اول، یک‌بار به پایین اسکرول کنید';
    } else if (segment) {
      ui.hint.textContent = queue
        ? `${fa(Math.abs(queue))} حرکت دیگر در صف است`
        : segment.dir > 0 ? 'در حال حرکت؛ اسکرول بعدی در صف قرار می‌گیرد' : 'در حال بازگشت به مرحلهٔ قبل';
    } else if (stage === 3) {
      ui.hint.textContent = 'سه حرکت کامل شد؛ اسکرول رو به پایین برای ادامه';
    } else {
      ui.hint.textContent = stage
        ? `برای حرکت ${fa(stage + 1)}، یک‌بار به پایین؛ برای برگشت، به بالا اسکرول کنید`
        : 'برای شروع دوباره، به پایین اسکرول کنید';
    }
  }

  const sparkPool = [];
  function makeSparks() {
    if (reducedMotion.matches || !sparkLayer) return;
    const box = film.querySelector('.implant-video-box').getBoundingClientRect();
    const stageRect = film.getBoundingClientRect();
    const originX = box.left + box.width * .52 - stageRect.left;
    const originY = box.top + box.height * .52 - stageRect.top;
    for (let i = 0; i < 24; i += 1) {
      let dot = sparkPool[i];
      if (!dot) {
        dot = document.createElement('i');
        dot.className = 'spark';
        sparkPool.push(dot);
        sparkLayer.append(dot);
      }
      dot.getAnimations().forEach(animation => animation.cancel());
      const size = 2 + Math.random() * 4;
      const dx = (Math.random() - .5) * 210;
      const dy = (Math.random() - .5) * 170;
      const delay = Math.random() * 300;
      dot.style.left = `${originX}px`;
      dot.style.top = `${originY}px`;
      dot.style.width = `${size}px`;
      dot.style.height = `${size}px`;
      dot.animate([
        { opacity: 0, transform: 'translate(-50%,-50%) scale(.2)' },
        { opacity: 1, transform: 'translate(-50%,-50%) scale(1)', offset: .12 },
        { opacity: 0, transform: `translate(calc(-50% + ${dx}px),calc(-50% + ${dy}px)) scale(.1)` }
      ], { duration: 1050 + Math.random() * 550, delay, easing: 'cubic-bezier(.16,.68,.24,1)', fill: 'none' });
    }
  }

  function releaseLock(destination) {
    if (!active) return;
    active = false;
    segmentToken += 1;
    cancelAnimationFrame(frameRequest);
    frameRequest = 0;
    segment = null;
    queue = 0;
    video.pause();
    reverse.pause();
    film.classList.remove('is-active', 'is-playing', 'is-reversing');
    root.classList.remove('implant-scroll-locked');
    root.style.removeProperty('--implant-lock-top');
    const y = Math.max(0, Math.round(destination));
    root.style.scrollBehavior = 'auto';
    window.scrollTo(0, y);
    requestAnimationFrame(() => { root.style.scrollBehavior = ''; });
  }

  function stopScrollTween() {
    if (!scrollTween) return;
    cancelAnimationFrame(scrollTween.frame);
    scrollTween = null;
    root.style.scrollBehavior = '';
  }

  function easeOutOfFilm(dir) {
    if (!active) return;
    if (dir > 0 && completed && stage === 3) completedOnce = true;
    const services = document.getElementById('services');
    const previous = film.previousElementSibling;
    const header = document.querySelector('.header');
    const headerOffset = header?.getBoundingClientRect().height || 0;
    // The body is fixed with a negative top while pinned, so child rects are viewport-relative.
    const destination = dir > 0 && services
      ? (nextSectionY ?? lockY + film.offsetHeight - headerOffset - 8)
      : dir < 0 && previous
        ? (previousSectionY ?? Math.max(0, lockY - innerHeight))
        : Math.max(0, lockY + (dir > 0 ? film.offsetHeight : -innerHeight));
    const from = lockY;
    const to = Math.max(0, Math.min(destination, maxDocumentScrollY));

    active = false;
    segmentToken += 1;
    cancelAnimationFrame(frameRequest);
    frameRequest = 0;
    segment = null;
    queue = 0;
    video.pause();
    reverse.pause();
    film.classList.remove('is-active', 'is-playing', 'is-reversing');
    root.classList.remove('implant-scroll-locked');
    root.style.removeProperty('--implant-lock-top');
    root.style.scrollBehavior = 'auto';
    // Re-anchor to the exact pinned document position before easing away, so unlock never flashes.
    window.scrollTo(0, from);

    const durationMs = 1250;
    const start = performance.now();
    const tween = { frame: 0 };
    scrollTween = tween;
    const tick = now => {
      if (scrollTween !== tween) return;
      const t = clamp((now - start) / durationMs, 0, 1);
      const eased = t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      window.scrollTo(0, from + (to - from) * eased);
      if (t < 1) tween.frame = requestAnimationFrame(tick);
      else {
        window.scrollTo(0, to);
        scrollTween = null;
        root.style.scrollBehavior = '';
      }
    };
    tween.frame = requestAnimationFrame(tick);
  }

  function completeForward() {
    completed = true;
    stage = 3;
    ui.replay.hidden = false;
    renderUI();
    ui.hint.textContent = 'برای ادامه، یک‌بار دیگر به پایین اسکرول کنید';
    // Hold the exact final frame and keep the page pinned until the next forward gesture.
  }

  function completeBackward() {
    completed = false;
    stage = 0;
    renderUI();
    ui.hint.textContent = 'برای بازگشت به بخش قبلی، یک‌بار دیگر به بالا اسکرول کنید';
    // Hold frame zero; only a further upward gesture leaves the film.
  }

  async function animateSegment(dir, from, to, startOverride = null, continueSameMedia = false, chapterNumber = null) {
    if (!active || (from === to && startOverride === null)) return;
    const media = dir > 0 ? video : reverse;
    const timelineStart = boundary(from);
    const timelineEnd = boundary(to);
    const start = startOverride ?? (dir > 0 ? timelineStart : duration() - timelineStart);
    const end = dir > 0 ? timelineEnd : duration() - timelineEnd;
    const sameMediaAlreadyPlaying = continueSameMedia && media === (segment?.media || media);

    if (!sameMediaAlreadyPlaying) {
      video.pause();
      reverse.pause();
    }
    media.playbackRate = 1;
    segment = { dir, from, to, media, start, end, chain: continueSameMedia, chapter: chapterNumber ?? (dir > 0 ? to : from) };
    everStarted = true;
    film.classList.add('is-playing');
    film.classList.toggle('is-reversing', dir < 0);
    makeSparks();
    renderUI({ animate: true });
    setHint();

    const token = ++segmentToken;
    try {
      if (!sameMediaAlreadyPlaying) {
        const alreadyPresented = media.classList.contains('is-visible') && media.readyState >= 2 && !media.seeking && Math.abs(media.currentTime - start) <= .015;
        if (!alreadyPresented) await prepareMedia(media, start);
        if (token !== segmentToken || !active) return;
        // Swap only after the target decoder has sought and presented its first correct frame.
        video.classList.toggle('is-visible', media === video);
        reverse.classList.toggle('is-visible', media === reverse);
      }
    } catch {
      if (token === segmentToken && active) switchToFallback();
      return;
    }

    const playPromise = media.play();
    if (playPromise?.catch) {
      playPromise.catch(() => {
        if (token === segmentToken && active) switchToFallback();
      });
    }

    const tick = async () => {
      if (!active || token !== segmentToken || !segment) return;
      const now = media.currentTime;
      const traveled = Math.abs(now - start);
      const remaining = Math.abs(end - now);
      // Quick chapter playback: 1.2x edge ramp, 2.35x cruise. Chains stay at cruise.
      let rate = segment.chain ? 2.35 : (traveled < .3 ? 1.2 + 1.15 * traveled / .3 : 2.35);
      const queuedContinues = Math.sign(queue) === dir && ((dir > 0 && to < 3) || (dir < 0 && to > 0));
      if (!segment.chain && !queuedContinues && remaining < .45) rate = Math.min(rate, 1.2 + 1.15 * remaining / .45);
      media.playbackRate = clamp(rate, 1.2, 2.35);
      setTime(dir > 0 ? now : duration() - now);
      const activePart = segment.chapter;
      progressParts[activePart - 1]?.style.setProperty('--step-progress', String(segmentProgress()));

      // Both files advance in media time. Narrative reverse therefore reaches a higher timestamp.
      const atBoundary = now >= end - .025;
      if (atBoundary) {
        const finished = segment;
        const queuedDir = Math.sign(queue);
        const canChain = queuedDir && ((queuedDir > 0 && to < 3) || (queuedDir < 0 && to > 0));
        if (!canChain) {
          media.pause();
          try {
            if (Math.abs(media.currentTime - end) > .004) {
              media.currentTime = end;
              if (media.seeking) await waitForEvent(media, 'seeked', 800);
            }
          } catch { /* retain the closest decoded boundary frame if seeking is unavailable */ }
          if (!active || token !== segmentToken) return;
        }
        stage = to;
        setTime(dir > 0 ? end : duration() - end);
        segment = null;
        film.classList.remove('is-playing', 'is-reversing');
        renderUI();

        if (dir > 0 && stage === 3) { completeForward(); return; }
        if (dir < 0 && stage === 0 && finished.from > finished.to) { completeBackward(); return; }

        if (canChain) {
          queue -= queuedDir;
          animateSegment(queuedDir, stage, stage + queuedDir, null, true);
          return;
        }
        setHint();
        return;
      }
      frameRequest = requestAnimationFrame(tick);
    };
    frameRequest = requestAnimationFrame(tick);
  }

  function requestStep(dir) {
    if (!active) return;
    if (segment) {
      if (dir === segment.dir) {
        const remainingForward = 3 - segment.to;
        const remainingBackward = segment.to;
        const maxQueue = dir > 0 ? remainingForward : remainingBackward;
        queue = dir > 0 ? Math.min(maxQueue, queue + 1) : -Math.min(maxQueue, Math.abs(queue) + 1);
        setHint();
        return;
      }
      // A counter-gesture turns the current move around; queued gestures are discarded.
      queue = 0;
      const currentForwardTime = segment.dir > 0 ? video.currentTime : duration() - reverse.currentTime;
      const returnBoundary = segment.from;
      const chapterNumber = segment.chapter;
      const newDir = -segment.dir;
      const timeOnNewMedia = newDir > 0 ? currentForwardTime : duration() - currentForwardTime;
      animateSegment(newDir, returnBoundary, returnBoundary, timeOnNewMedia, false, chapterNumber);
      return;
    }

    if (dir > 0 && stage < 3) {
      animateSegment(1, stage, stage + 1);
    } else if (dir < 0 && stage > 0) {
      animateSegment(-1, stage, stage - 1);
    } else if (dir > 0 && stage === 3) {
      easeOutOfFilm(1);
    } else if (dir < 0 && stage === 0) {
      easeOutOfFilm(-1);
    }
  }

  function finishWheelGesture() {
    window.clearTimeout(gestureTimer);
    if (!gesture) return;
    const current = gesture;
    gesture = null;
    if (current.total < 2) return;
    requestStep(current.dir);
  }

  function onWheel(event) {
    if (scrollTween) { stopScrollTween(); return; }
    if (!active || event.ctrlKey || Math.abs(event.deltaX) > Math.abs(event.deltaY)) return;
    event.preventDefault();
    let delta = event.deltaY;
    if (event.deltaMode === WheelEvent.DOM_DELTA_LINE) delta *= 16;
    else if (event.deltaMode === WheelEvent.DOM_DELTA_PAGE) delta *= innerHeight;
    const dir = Math.sign(delta);
    if (!dir) return;

    if (gesture && dir !== gesture.dir) {
      finishWheelGesture();
      gesture = null;
    }
    const magnitude = Math.abs(delta);
    if (!gesture) gesture = { dir, total: 0, peak: 0, last: performance.now(), decaying: false };
    // If a strong fresh swipe overtakes decaying trackpad inertia, count it separately.
    if (gesture.total > 8 && gesture.decaying && magnitude > gesture.peak * 1.55) {
      finishWheelGesture();
      gesture = { dir, total: 0, peak: 0, last: performance.now(), decaying: false };
    }
    if (magnitude < gesture.peak * .72) gesture.decaying = true;
    gesture.total += magnitude;
    gesture.peak = Math.max(gesture.peak, magnitude);
    gesture.last = performance.now();
    window.clearTimeout(gestureTimer);
    gestureTimer = window.setTimeout(finishWheelGesture, 120);
  }

  function canPin() {
    return innerHeight >= 620 && !reducedMotion.matches && !video.error && video.canPlayType('video/mp4') !== '';
  }

  function lockAtFilm() {
    const documentY = window.scrollY;
    const filmRect = film.getBoundingClientRect();
    lockY = Math.max(0, filmRect.top + documentY);
    const nextSection = film.nextElementSibling;
    const previous = film.previousElementSibling;
    const headerHeight = document.querySelector('.header')?.getBoundingClientRect().height || 0;
    maxDocumentScrollY = Math.max(0, document.documentElement.scrollHeight - innerHeight);
    nextSectionY = nextSection ? nextSection.getBoundingClientRect().top + documentY - headerHeight - 8 : lockY + film.offsetHeight;
    previousSectionY = previous ? Math.max(0, previous.getBoundingClientRect().top + documentY) : Math.max(0, lockY - innerHeight);
    root.style.scrollBehavior = 'auto';
    window.scrollTo(0, lockY);
    root.style.scrollBehavior = '';
    root.style.setProperty('--implant-lock-top', `${-Math.round(lockY)}px`);
    root.classList.add('implant-scroll-locked');
    film.classList.add('is-active');
    active = true;
    video.controls = false;
    video.classList.add('is-visible');
    reverse.classList.remove('is-visible');
    video.pause();
    reverse.pause();
    const frame = boundary(stage);
    try { video.currentTime = frame; } catch { /* wait for metadata */ }
    setTime(frame);
    renderUI();
    setHint();
    if (startAfterEntry) {
      startAfterEntry = false;
      requestAnimationFrame(() => requestStep(1));
    }
  }

  function maybeEnter() {
    // Once the user has left a completed story, keep its final implant frame as a static end state.
    if (active || completedOnce || !canPin()) return;
    const rect = film.getBoundingClientRect();
    if (bypassStoryTarget) {
      const targetTop = bypassStoryTarget.getBoundingClientRect().top;
      const headerHeight = document.querySelector('.header')?.getBoundingClientRect().height || 0;
      if (targetTop <= headerHeight + 16) bypassStoryTarget = null;
      else return;
    }
    const aligned = rect.top <= 2 && rect.bottom > innerHeight * .6;
    if (!aligned) return;
    const scrollingDownIntoStory = scrollDirection >= 0 && stage < 3;
    const scrollingUpToStory = scrollDirection < 0 && stage > 0;
    if (startAfterEntry || scrollingDownIntoStory || scrollingUpToStory || (!everStarted && stage === 0)) {
      enterObserver.disconnect();
      lockAtFilm();
    }
  }

  function switchToFallback() {
    if (active) {
      const destination = scrollDirection < 0 ? lockY - 2 : lockY + film.offsetHeight + 2;
      releaseLock(destination);
    }
    video.controls = true;
    video.classList.add('is-visible');
    reverse.classList.remove('is-visible');
    ui.fallback.hidden = false;
    enterObserver.disconnect();
  }

  const enterObserver = new IntersectionObserver(() => maybeEnter(), { threshold: [0, .1, .5, 1] });
  enterObserver.observe(film);
  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    const previousY = lastScrollY;
    if (Math.abs(y - previousY) > .5) scrollDirection = Math.sign(y - previousY);
    const storyTop = film.getBoundingClientRect().top + y;
    const crossedForward = scrollDirection > 0 && stage < 3 && previousY < storyTop && y >= storyTop;
    const crossedBackward = scrollDirection < 0 && stage > 0 && previousY > storyTop + film.offsetHeight && y <= storyTop + film.offsetHeight;
    lastScrollY = y;
    if (!bypassStoryTarget && !active && !completedOnce && canPin() && (crossedForward || crossedBackward)) {
      enterObserver.disconnect();
      lockAtFilm();
      return;
    }
    maybeEnter();
  }, { passive: true });
  document.addEventListener('wheel', onWheel, { passive: false });
  document.addEventListener('keydown', event => {
    if (scrollTween) { stopScrollTween(); return; }
    if (!active) return;
    const keys = ['ArrowDown', 'PageDown', ' ', 'End', 'ArrowUp', 'PageUp', 'Home'];
    if (!keys.includes(event.key)) return;
    event.preventDefault();
    if (event.repeat) return;
    requestStep(['ArrowUp', 'PageUp', 'Home'].includes(event.key) ? -1 : 1);
  }, { capture: true });

  document.addEventListener('touchstart', () => { if (scrollTween) stopScrollTween(); }, { capture: true, passive: true });
  film.addEventListener('touchstart', event => {
    touchStartY = active && event.touches.length === 1 ? event.touches[0].clientY : null;
  }, { passive: true });
  film.addEventListener('touchmove', event => {
    if (active && touchStartY !== null) event.preventDefault();
  }, { passive: false });
  film.addEventListener('touchend', event => {
    if (active && touchStartY !== null && event.changedTouches.length) {
      const delta = touchStartY - event.changedTouches[0].clientY;
      if (Math.abs(delta) >= 6) requestStep(Math.sign(delta));
    }
    touchStartY = null;
  }, { passive: true });

  document.addEventListener('click', event => {
    const link = event.target.closest?.('a[href^="#"]');
    if (!link) return;
    if (link.hasAttribute('data-service-jump')) {
      const jumpTarget = document.getElementById(decodeURIComponent(link.getAttribute('href').slice(1)));
      if (jumpTarget && (film.compareDocumentPosition(jumpTarget) & Node.DOCUMENT_POSITION_FOLLOWING)) {
        bypassStoryTarget = jumpTarget;
      }
      return;
    }
    if (scrollTween) stopScrollTween();
    if (link.hasAttribute('data-implant-start')) {
      event.preventDefault();
      history.pushState(null, '', `#${film.id}`);
      bypassStoryTarget = null;
      if (completedOnce) {
        film.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      if (active) { requestStep(1); return; }
      startAfterEntry = true;
      enterObserver.observe(film);
      window.scrollTo({ top: film.getBoundingClientRect().top + window.scrollY, behavior: 'smooth' });
      return;
    }
    if (active) { event.preventDefault(); return; }
    const target = document.getElementById(decodeURIComponent(link.getAttribute('href').slice(1)));
    if (!target || target === film) return;
    if ((film.compareDocumentPosition(target) & Node.DOCUMENT_POSITION_FOLLOWING) && !(completed && stage === 3)) {
      event.preventDefault();
      film.scrollIntoView({ behavior: 'auto', block: 'start' });
    }
  }, { capture: true });

  video.addEventListener('loadedmetadata', () => {
    if (!segment) {
      const frame = boundary(stage);
      try { video.currentTime = frame; } catch { /* metadata is now available on the next render */ }
      if (active) setTime(frame);
    }
  });
  video.addEventListener('timeupdate', () => { if (!active) setTime(video.currentTime); });
  video.addEventListener('error', switchToFallback);
  reverse.addEventListener('error', switchToFallback);
  reducedMotion.addEventListener('change', event => { if (event.matches) switchToFallback(); });
  window.addEventListener('resize', () => { if (innerHeight < 620) switchToFallback(); }, { passive: true });
  window.addEventListener('pagehide', () => {
    window.clearTimeout(gestureTimer);
    cancelAnimationFrame(frameRequest);
  }, { once: true });

  ui.replay.addEventListener('click', () => {
    completed = false;
    completedOnce = false;
    everStarted = false;
    stage = 0;
    segment = null;
    queue = 0;
    video.pause();
    reverse.pause();
    try { video.currentTime = 0; } catch { /* metadata may not be ready */ }
    setTime(0);
    ui.replay.hidden = true;
    renderUI();
    setHint();
    if (!active) {
      film.scrollIntoView({ behavior: 'smooth', block: 'start' });
      enterObserver.observe(film);
    }
  });

  if (!canPin()) switchToFallback();
  renderUI();
}
