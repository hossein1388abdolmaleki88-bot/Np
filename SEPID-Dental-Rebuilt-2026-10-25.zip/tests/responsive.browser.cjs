const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const path = require('node:path');
const { spawn } = require('node:child_process');
const ROOT = path.resolve(__dirname, '..'), PORT = 3012;
const wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
 const server=spawn('python',['serve.py',String(PORT)],{cwd:ROOT,stdio:'ignore'}); let browser;
 try {
  for(let i=0;i<60;i++){try{if((await fetch(`http://127.0.0.1:${PORT}/index.html`)).ok)break}catch{} await wait(100)}
  browser=await chromium.launch({headless:true,args:['--no-sandbox']}); const page=await browser.newPage();
  await page.route('**/js/main.js*',r=>r.fulfill({status:200,contentType:'text/javascript',body:''}));
  const report=[];
  for(const [width,height] of [[1920,1080],[1440,900],[1280,720],[1024,768],[820,1180],[390,844],[360,640]]){
   await page.setViewportSize({width,height}); await page.goto(`http://127.0.0.1:${PORT}/index.html`,{waitUntil:'domcontentloaded'}); await wait(50);
   const item=await page.evaluate(({width,height})=>{
    const box=sel=>{const e=document.querySelector(sel);if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,width:r.width,height:r.height}};
    const a=box('.hero-copy'),b=box('#hero-art');
    const heroOverlap=a&&b&&a.x<b.right&&a.right>b.x&&a.y<b.bottom&&a.bottom>b.y;
    return {width,height,scrollWidth:document.documentElement.scrollWidth,viewportWidth:innerWidth,heroOverlap,heroCopy:a,heroArt:b,filmTitle:box('[data-heading]'),filmProgress:box('[data-progress]')};
   },{width,height});
   assert(item.scrollWidth<=item.viewportWidth+1,`${width}x${height}: horizontal overflow ${item.scrollWidth}`);
   assert(!item.heroOverlap,`${width}x${height}: hero copy overlaps art`);
   report.push(item);
  }
  await page.setViewportSize({width:390,height:844});
  await page.goto(`http://127.0.0.1:${PORT}/index.html`,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>document.querySelectorAll('#services .service-border').length===4);
  await page.evaluate(()=>scrollTo({top:document.querySelector('#services').offsetTop,behavior:'instant'}));
  await wait(250);
  const services=await page.evaluate(()=>({
   order:['home','services','implant-story','journey'].map(id=>document.getElementById(id).getBoundingClientRect().top+scrollY),
   cards:[...document.querySelectorAll('#services .services-card')].map(e=>{const r=e.getBoundingClientRect();return {x:r.left,right:r.right,y:r.top,bottom:r.bottom}}),
   links:[...document.querySelectorAll('#services .services-card .service-more')].map(a=>a.getAttribute('href')),
   borders:[...document.querySelectorAll('#services .services-card')].map(c=>({phase:c.style.getPropertyValue('--orbit-phase'),duration:c.style.getPropertyValue('--orbit-duration'),delay:c.style.getPropertyValue('--orbit-delay')})),
   glass:{filter:getComputedStyle(document.querySelector('#services .services-card')).backdropFilter,background:getComputedStyle(document.querySelector('#services .services-card')).backgroundImage},
   entrance:{animation:getComputedStyle(document.querySelector('#services .services-card')).animationName,introEntered:document.querySelector('#services .services-intro').classList.contains('is-entered'),firstCardEntered:document.querySelector('#services .services-card').classList.contains('is-entered'),lastCardEntered:document.querySelector('#services .services-card:last-of-type').classList.contains('is-entered'),transition:getComputedStyle(document.querySelector('#services .services-card')).transitionDuration},
   toolbarTop:document.querySelector('#services .services-toolbar').getBoundingClientRect().top,
   servicesActive:document.documentElement.classList.contains('services-page-active'),
   globalHeaderOpacity:getComputedStyle(document.querySelector('.header')).opacity,
   globalMobileBook:getComputedStyle(document.querySelector('.mobile-book')).display,
   scrollWidth:document.documentElement.scrollWidth,viewportWidth:innerWidth
  }));
  assert.deepEqual(services.order.slice().sort((a,b)=>a-b),services.order,'section order home → services → implant → journey');
  assert.equal(services.cards.length,4,'four service cards');
  assert.deepEqual(services.links,['#implant-story','#journey','#comparison','#booking']);
  assert.equal(services.borders.length,4,'one animated border per service card');
  assert(services.borders.every(b=>b.phase===services.borders[0].phase&&b.duration===services.borders[0].duration&&b.delay===services.borders[0].delay),'service borders must stay synchronized');
  assert(services.glass.filter.includes('blur')&&services.glass.background.includes('linear-gradient'),'service cards should use a frosted-glass surface');
  assert.equal(services.entrance.animation,'none','services reveal should not be tied to a linear scroll timeline');
  assert(services.entrance.introEntered&&services.entrance.firstCardEntered,'intro and visible cards should reveal on arrival');
  assert(!services.entrance.lastCardEntered,'offscreen cards should reveal when they enter the viewport');
  assert(services.entrance.transition.includes('0.82s'),'services reveal should use a smooth eased transition');
  assert(services.cards.every(card=>card.right-card.x>300),'service card width collapsed during entrance motion');
  assert(services.servicesActive&&Math.abs(services.toolbarTop)<1,'local services toolbar is not pinned');
  assert.equal(services.globalHeaderOpacity,'0','global header should yield to local services toolbar on mobile');
  assert.equal(services.globalMobileBook,'none','global mobile booking bar should not cover service cards');
  assert(services.scrollWidth<=services.viewportWidth+1,'services screen has horizontal overflow');
  await page.screenshot({path:path.join(ROOT,'test-artifacts/services-glass-motion-mobile.png')});
  await page.screenshot({path:path.join(ROOT,'test-artifacts/services-mobile-preview.png'),animations:'disabled'});
  report.push({servicesMobile:services,screenshot:'test-artifacts/services-mobile-preview.png',motionScreenshot:'test-artifacts/services-glass-motion-mobile.png'});
  require('node:fs').writeFileSync(path.join(ROOT,'test-artifacts/responsive-results.json'),JSON.stringify(report,null,2)); console.log(JSON.stringify(report,null,2));
 }finally{await browser?.close();server.kill('SIGTERM')}
})().catch(e=>{console.error(e);process.exit(1)});
