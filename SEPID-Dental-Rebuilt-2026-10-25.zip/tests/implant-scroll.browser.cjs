const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const path = require('node:path');
const { spawn } = require('node:child_process');
const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.env.SEPID_TEST_PORT || 3010);
const URL = `http://127.0.0.1:${PORT}/index.html`;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

(async () => {
  const server = spawn('python', ['serve.py', String(PORT)], { cwd: ROOT, stdio: 'ignore' });
  let browser;
  try {
    for (let i = 0; i < 60; i++) { try { if ((await fetch(URL)).ok) break; } catch {} await wait(100); }
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
    // The film tests intentionally bypass the unrelated WebGL loop for deterministic timing.
    await page.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
    await page.goto(URL, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);

    const enter = async () => {
      await page.evaluate(() => {
        const film = document.querySelector('#implant-story');
        window.scrollTo({ top: film.getBoundingClientRect().top + window.scrollY, behavior: 'instant' });
      });
      await page.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-active'));
    };
    const sendWheel = async delta => { await page.mouse.move(700, 350); await page.mouse.wheel(0, delta); };
    const stageIs = n => page.locator('[data-progress]').getAttribute('aria-valuenow').then(value => value === String(n));
    const waitMove = async n => {
      await page.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-playing'), null, { timeout: 3000 });
      await page.waitForFunction(target => !document.querySelector('#implant-story').classList.contains('is-playing') && document.querySelector('[data-progress]').getAttribute('aria-valuenow') === String(target), n, { timeout: 7000 });
    };
    const resetAndEnter = async () => {
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
      await installTimingLog();
      await enter();
    };
    const results = {};
    const installTimingLog = () => page.evaluate(() => {
      const film = document.querySelector('#implant-story');
      window.__chapterDurations = []; let began = 0;
      const isPlaying = value => (value || '').split(/\s+/).includes('is-playing');
      new MutationObserver(records => records.forEach((record, index) => {
        const wasPlaying = isPlaying(record.oldValue);
        const nextValue = records[index + 1]?.oldValue ?? film.className;
        const nowPlaying = isPlaying(nextValue);
        if (nowPlaying && !wasPlaying) began = performance.now();
        if (wasPlaying && !nowPlaying && began) { window.__chapterDurations.push(Math.round(performance.now() - began)); began = 0; }
      })).observe(film, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });
    });
    await installTimingLog();

    // Sub-2 px total is ignored; an actual 2 px mouse flick is exactly chapter 1.
    await enter();
    await sendWheel(1); await wait(220);
    assert.equal(await page.locator('[data-progress]').getAttribute('aria-valuenow'), '0');
    assert.equal(await page.locator('#implant-story').evaluate(e => e.classList.contains('is-playing')), false);
    let start = Date.now(); await sendWheel(2);
    await page.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-playing'));
    const zoomDuring = await page.locator('.implant-video-box').evaluate(e => getComputedStyle(e).transform);
    const videoZoomDuring = await page.locator('[data-video]').evaluate(e => getComputedStyle(e).transform);
    await waitMove(1); await wait(30);
    const zoomSettled = await page.locator('.implant-video-box').evaluate(e => getComputedStyle(e).transform);
    const videoZoomSettled = await page.locator('[data-video]').evaluate(e => getComputedStyle(e).transform);
    results.flick2px = { elapsedMs: Date.now() - start, exactBoundary: await page.locator('[data-video]').evaluate(v => v.currentTime), playbackMs: await page.evaluate(() => window.__chapterDurations.at(-1)), zoomDuring, zoomSettled, videoZoomDuring, videoZoomSettled };
    assert(Math.abs(results.flick2px.exactBoundary - 3.1) < .01);
    assert.deepEqual([zoomDuring, zoomSettled, videoZoomDuring, videoZoomSettled], ['none', 'none', 'none', 'none']);

    // Forty wheel notches in one burst remain one gesture.
    start = Date.now();
    const wheelCdp = await page.context().newCDPSession(page);
    for (let i = 0; i < 40; i++) await wheelCdp.send('Input.dispatchMouseEvent', { type: 'mouseWheel', x: 700, y: 350, deltaY: 120, deltaX: 0 });
    await waitMove(2);
    results.fast40Notches = { elapsedMs: Date.now() - start, stage: await page.locator('[data-progress]').getAttribute('aria-valuenow') };
    assert.equal(results.fast40Notches.stage, '2');

    // Ctrl-wheel and horizontal wheel are ignored while the film is pinned.
    await resetAndEnter();
    await page.keyboard.down('Control'); await page.mouse.move(700, 350); await page.mouse.wheel(0, 120); await page.keyboard.up('Control');
    await page.mouse.wheel(120, 0); await wait(200);
    results.ctrlAndHorizontalWheel = { stage: await page.locator('[data-progress]').getAttribute('aria-valuenow'), playing: await page.locator('#implant-story').evaluate(e => e.classList.contains('is-playing')) };
    assert.equal(results.ctrlAndHorizontalWheel.stage, '0'); assert.equal(results.ctrlAndHorizontalWheel.playing, false);

    // A 1.5 s decaying browser-input tail is one gesture. Use its own page so prior gestures cannot contaminate it.
    const tailContext = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    await tailContext.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    const tailPage = await tailContext.newPage(); await tailPage.goto(URL, { waitUntil: 'domcontentloaded' });
    await tailPage.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
    await tailPage.evaluate(() => { const f = document.querySelector('#implant-story'); scrollTo({ top: f.getBoundingClientRect().top + scrollY, behavior: 'instant' }); });
    await tailPage.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-active'));
    const tailCdp = await tailContext.newCDPSession(tailPage);
    const tailStarted = Date.now();
    for (let i = 0; i < 33; i++) { const delta = Math.max(2, Math.round(78 * Math.exp(-i / 7.8))); await Promise.all([0, 1, 2].map(() => tailCdp.send('Input.dispatchMouseEvent', { type: 'mouseWheel', x: 700, y: 350, deltaY: delta, deltaX: 0 }))); await wait(30); }
    results.inertiaDispatchMs = Date.now() - tailStarted;
    await tailPage.waitForFunction(() => { const f = document.querySelector('#implant-story'); const n = Number(document.querySelector('[data-progress]').getAttribute('aria-valuenow')); return n > 0 && !f.classList.contains('is-playing'); }, null, { timeout: 15000 });
    results.inertiaTail15s = { elapsedMs: Date.now() - tailStarted, stage: await tailPage.locator('[data-progress]').getAttribute('aria-valuenow') };
    assert.equal(results.inertiaTail15s.stage, '1'); await tailContext.close();

    // Three and five distinct fast flicks chain, and the extra two clamp at chapter 3.
    for (const count of [3, 5]) {
      await resetAndEnter(); start = Date.now();
      for (let i = 0; i < count; i++) { await sendWheel(120); await wait(140); }
      await waitMove(3);
      await wait(250);
      const held = await page.evaluate(() => ({ active: document.querySelector('#implant-story').classList.contains('is-active'), pinned: document.documentElement.classList.contains('implant-scroll-locked'), time: document.querySelector('[data-video]').currentTime, y: scrollY }));
      results[`${count}QuickFlicks`] = { elapsedMs: Date.now() - start, held, chapterPlaybackMs: await page.evaluate(() => [...window.__chapterDurations]) };
      assert(held.active && held.pinned && Math.abs(held.time - 9.5) < .02);
      assert.equal(await page.locator('[data-progress]').getAttribute('aria-valuenow'), '3');
      if (count === 5) results.fiveClamp = 'held on chapter 3; no extra queued move';
      if (count === 3) {
        const reverse = [];
        for (const n of [2, 1, 0]) {
          start = Date.now(); await sendWheel(-120); await waitMove(n);
          reverse.push({ stage: n, elapsedMs: Date.now() - start, displayedTime: await page.locator('[data-time]').textContent(), reverseVisible: await page.locator('[data-reverse-video]').evaluate(v => v.classList.contains('is-visible')), reverseTime: await page.locator('[data-reverse-video]').evaluate(v => v.currentTime) });
        }
        results.reverse3to0 = reverse;
        assert.deepEqual(reverse.map(x => x.stage), [2, 1, 0]);
        assert(reverse.every(x => x.reverseVisible));
        assert(Math.abs(reverse[0].reverseTime - (9.541667 - 6.7)) < .04);
        assert(Math.abs(reverse[1].reverseTime - (9.541667 - 3.1)) < .04);
        assert(Math.abs(reverse[2].reverseTime - 9.541667) < .04);
      }
    }

    // Page stays pinned at chapter 3; only the next forward gesture starts a 1.25 s rAF ease.
    const finalY = await page.evaluate(() => scrollY);
    await page.evaluate(() => document.querySelector('a[href="#services"]')?.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })));
    await page.evaluate(() => { document.querySelector('a[href="#services"]')?.focus(); window.scrollTo({ top: 5000, behavior: 'instant' }); });
    await wait(150); assert.equal(await page.evaluate(() => scrollY), finalY, 'pinned scroll position changed before the next gesture');
    assert.equal(await page.locator('#implant-story').evaluate(e => e.classList.contains('is-active')), true);
    const easeSamples = []; start = Date.now(); await sendWheel(2);
    for (let i = 0; i < 14; i++) { await wait(100); easeSamples.push(await page.evaluate(() => scrollY)); }
    results.afterThirdHold = { pinnedBeforeNextInput: true, finalFrameY: finalY };
    results.easeToNextSection = { elapsedMs: Date.now() - start, samples: easeSamples, endY: await page.evaluate(() => scrollY) };
    assert(results.easeToNextSection.elapsedMs >= 900);
    assert(easeSamples.filter((y, i) => i && y > easeSamples[i - 1]).length >= 8);
    assert(results.easeToNextSection.endY > 1000);
    await wait(250);

    // Once completed and exited, returning to the page top or the story keeps the final implant-in-jaw frame static.
    await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' })); await wait(250);
    const endState = async () => page.evaluate(() => ({
      active: document.querySelector('#implant-story').classList.contains('is-active'),
      playing: document.querySelector('#implant-story').classList.contains('is-playing'),
      locked: document.documentElement.classList.contains('implant-scroll-locked'),
      time: document.querySelector('[data-video]').currentTime,
      paused: document.querySelector('[data-video]').paused,
      visible: document.querySelector('[data-video]').classList.contains('is-visible'),
      zoom: getComputedStyle(document.querySelector('.implant-video-box')).transform,
      videoZoom: getComputedStyle(document.querySelector('[data-video]')).transform
    }));
    results.finalStateAtTop = await endState();
    assert(!results.finalStateAtTop.active && !results.finalStateAtTop.playing && !results.finalStateAtTop.locked);
    assert(results.finalStateAtTop.paused && results.finalStateAtTop.visible && Math.abs(results.finalStateAtTop.time - 9.5) < .02);
    assert.equal(results.finalStateAtTop.zoom, 'none'); assert.equal(results.finalStateAtTop.videoZoom, 'none');
    await page.evaluate(() => { const film = document.querySelector('#implant-story'); window.scrollTo({ top: film.getBoundingClientRect().top + scrollY, behavior: 'instant' }); }); await wait(250);
    results.staticStoryRevisit = await endState();
    assert(!results.staticStoryRevisit.active && !results.staticStoryRevisit.playing && !results.staticStoryRevisit.locked);
    assert(results.staticStoryRevisit.paused && results.staticStoryRevisit.visible && Math.abs(results.staticStoryRevisit.time - 9.5) < .02);
    assert.equal(results.staticStoryRevisit.zoom, 'none'); assert.equal(results.staticStoryRevisit.videoZoom, 'none');

    // Opposite gesture mid-chapter cancels queued down moves and returns smoothly to the boundary.
    await resetAndEnter(); await sendWheel(120);
    await page.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-playing'));
    await wait(200); await sendWheel(120); await wait(140); await sendWheel(-120);
    await waitMove(0);
    results.midMoveCounterGesture = { stage: await page.locator('[data-progress]').getAttribute('aria-valuenow'), time: await page.locator('[data-time]').textContent(), reverseVisible: await page.locator('[data-reverse-video]').evaluate(v => v.classList.contains('is-visible')) };
    assert.equal(results.midMoveCounterGesture.stage, '0');
    assert(results.midMoveCounterGesture.reverseVisible);

    // Every supported keyboard key advances/reverses one chapter; End never bypasses the film.
    const keyStages = [];
    for (const [key, target] of [['ArrowDown', 1], ['PageDown', 2], ['End', 3], ['Home', 2], ['PageUp', 1], ['ArrowUp', 0], [' ', 1]]) {
      await page.keyboard.press(key); await waitMove(target); keyStages.push({ key: key === ' ' ? 'Space' : key, stage: Number(await page.locator('[data-progress]').getAttribute('aria-valuenow')) });
    }
    results.keyboard = keyStages;
    assert.deepEqual(keyStages.map(x => x.stage), [1, 2, 3, 2, 1, 0, 1]);

    // Touch: one >=6 px swipe advances one chapter; it is measured at touchend, not every touchmove.
    const touchContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
    await touchContext.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    const touchPage = await touchContext.newPage();
    await touchPage.goto(URL, { waitUntil: 'domcontentloaded' });
    await touchPage.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
    await touchPage.evaluate(() => { const f = document.querySelector('#implant-story'); scrollTo({ top: f.getBoundingClientRect().top + scrollY, behavior: 'instant' }); });
    await touchPage.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-active'));
    const cdp = await touchContext.newCDPSession(touchPage);
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: 195, y: 680, id: 1 }] });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: 195, y: 620, id: 1 }] });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await touchPage.waitForFunction(() => document.querySelector('#implant-story').classList.contains('is-playing'));
    await touchPage.waitForFunction(() => !document.querySelector('#implant-story').classList.contains('is-playing') && document.querySelector('[data-progress]').getAttribute('aria-valuenow') === '1', null, { timeout: 7000 });
    results.touchSwipe = { stage: await touchPage.locator('[data-progress]').getAttribute('aria-valuenow') };
    assert.equal(results.touchSwipe.stage, '1');
    await touchContext.close();

    // Reduced motion / short-height fallback: controls available, no scroll lock.
    const reduceContext = await browser.newContext({ viewport: { width: 1280, height: 720 }, reducedMotion: 'reduce' });
    await reduceContext.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    const reducePage = await reduceContext.newPage(); await reducePage.goto(URL, { waitUntil: 'domcontentloaded' });
    await reducePage.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
    results.reducedMotionFallback = await reducePage.locator('[data-video]').evaluate(v => ({ controls: v.controls, locked: document.documentElement.classList.contains('implant-scroll-locked') }));
    const shortContext = await browser.newContext({ viewport: { width: 360, height: 600 } });
    await shortContext.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    const shortPage = await shortContext.newPage(); await shortPage.goto(URL, { waitUntil: 'domcontentloaded' });
    await shortPage.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
    results.shortFallback = await shortPage.locator('[data-video]').evaluate(v => ({ controls: v.controls, locked: document.documentElement.classList.contains('implant-scroll-locked') }));
    await reduceContext.close(); await shortContext.close();
    const errorContext = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    await errorContext.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    await errorContext.route('**/assets/implant-story.mp4', route => route.abort());
    await errorContext.route('**/assets/implant-story-reverse.mp4', route => route.abort());
    const errorPage = await errorContext.newPage(); await errorPage.goto(URL, { waitUntil: 'domcontentloaded' });
    await errorPage.waitForFunction(() => document.querySelector('[data-fallback]').hidden === false, null, { timeout: 10000 });
    results.videoErrorFallback = await errorPage.locator('[data-video]').evaluate(v => ({ controls: v.controls, locked: document.documentElement.classList.contains('implant-scroll-locked') }));
    await errorContext.close();
    assert(results.videoErrorFallback.controls && !results.videoErrorFallback.locked);
    assert(results.reducedMotionFallback.controls && !results.reducedMotionFallback.locked);
    assert(results.shortFallback.controls && !results.shortFallback.locked);

    // Service cards: secondary links jump to their real target without triggering the implant story;
    // the implant CTA is the sole route that enters and starts chapter one.
    const servicesContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
    await servicesContext.route('**/js/main.js*', route => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    const servicesPage = await servicesContext.newPage();
    await servicesPage.goto(URL, { waitUntil: 'domcontentloaded' });
    await servicesPage.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
    const sourceOrder = await servicesPage.evaluate(() => ['home', 'services', 'implant-story', 'journey'].map(id => document.getElementById(id).getBoundingClientRect().top + scrollY));
    assert(sourceOrder[0] < sourceOrder[1] && sourceOrder[1] < sourceOrder[2] && sourceOrder[2] < sourceOrder[3], 'home → services → implant → journey order');
    await servicesPage.locator('#services .services-card a[href="#journey"][data-service-jump]').click();
    await servicesPage.waitForFunction(() => location.hash === '#journey');
    await wait(1000);
    results.serviceJump = await servicesPage.evaluate(() => ({ hash: location.hash, y: scrollY, targetY: document.querySelector('#journey').getBoundingClientRect().top + scrollY, filmActive: document.querySelector('#implant-story').classList.contains('is-active') }));
    assert.equal(results.serviceJump.hash, '#journey');
    assert(Math.abs(results.serviceJump.y - results.serviceJump.targetY) < 300, 'journey CTA did not jump to its section');
    assert.equal(results.serviceJump.filmActive, false, 'a non-implant card started the film');
    await servicesPage.goto(URL, { waitUntil: 'domcontentloaded' });
    await servicesPage.waitForFunction(() => document.querySelector('[data-video]')?.readyState >= 2);
    await servicesPage.locator('#services .services-card a[data-implant-start]').click();
    await servicesPage.waitForFunction(() => document.documentElement.classList.contains('implant-scroll-locked') && document.querySelector('#implant-story').classList.contains('is-playing'), null, { timeout: 10000 });
    await servicesPage.waitForFunction(() => !document.querySelector('#implant-story').classList.contains('is-playing') && document.querySelector('[data-progress]').getAttribute('aria-valuenow') === '1', null, { timeout: 10000 });
    results.implantServiceCTA = await servicesPage.evaluate(() => ({ hash: location.hash, stage: document.querySelector('[data-progress]').getAttribute('aria-valuenow'), active: document.querySelector('#implant-story').classList.contains('is-active'), locked: document.documentElement.classList.contains('implant-scroll-locked') }));
    assert.equal(results.implantServiceCTA.hash, '#implant-story');
    assert.equal(results.implantServiceCTA.stage, '1');
    assert(results.implantServiceCTA.active && results.implantServiceCTA.locked);
    await servicesContext.close();
    assert.deepEqual(errors, []);
    const report = { browser: 'Chromium', h264: await page.locator('[data-video]').evaluate(v => ({ canPlay: v.canPlayType('video/mp4'), readyState: v.readyState, duration: v.duration })), results, consoleErrors: errors };
    require('node:fs').writeFileSync(path.join(ROOT, 'test-artifacts/implant-scroll-results.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify(report, null, 2));
  } finally {
    await browser?.close();
    server.kill('SIGTERM');
  }
})().catch(error => { console.error(error); process.exit(1); });
