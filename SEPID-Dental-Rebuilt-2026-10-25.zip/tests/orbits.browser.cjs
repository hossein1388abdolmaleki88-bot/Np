const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const path = require('node:path');
const { spawn } = require('node:child_process');
const ROOT = path.resolve(__dirname, '..');
const PORT = 3011;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
(async () => {
  const server = spawn('python', ['serve.py', String(PORT)], { cwd: ROOT, stdio: 'ignore' });
  let browser;
  try {
    for (let i = 0; i < 60; i++) { try { if ((await fetch(`http://127.0.0.1:${PORT}/index.html`)).ok) break; } catch {} await wait(100); }
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader'] });
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    await page.addInitScript(() => { window.SEPID_3D_OPTIONS = { maxPixelRatio: 1, mobilePixelRatio: 1, minPixelRatio: 1, shadowMapSize: 256, particleCount: 8, introEnabled: false }; });
    await page.goto(`http://127.0.0.1:${PORT}/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => window.sepidTooth?.getStats?.().ready, null, { timeout: 20000 });
    await page.waitForTimeout(1500); // allow intro pose to settle
    const art = page.locator('#hero-art');
    const capture = async name => {
      const box = await art.boundingBox();
      await page.screenshot({ path: path.join(ROOT, `test-artifacts/${name}`), clip: { x: Math.floor(box.x), y: Math.floor(box.y), width: Math.floor(box.width), height: Math.floor(box.height) }, timeout: 90000 });
    };
    await capture('orbits-settled-0.png');
    const before = await page.evaluate(() => ({
      stats: sepidTooth.getStats(),
      rotations: sepidTooth.orbits.entries.map(({ group }) => group.rotation.toArray().slice(0, 3)),
      particles: sepidTooth.orbits.entries.flatMap(({ particles }) => particles.map(p => ({ family: p.colorFamily, phase: p.phase, speed: p.speed, position: p.position.toArray(), radius: p.children[0].geometry.parameters.radius, color: p.children[0].material.color.getHexString(), roughness: p.children[0].material.roughness, metalness: p.children[0].material.metalness, glow: p.glow.material.uniforms.uGlow.value }))),
      platform: (() => {
        const p = sepidTooth.platform;
        return { sideColor: p.edgeMaterial.color.getHexString(), topColor: p.topMaterial.color.getHexString(), goldRimColor: p.goldRimMaterial.color.getHexString(), veinColor: p.veinMaterial.color.getHexString(), veinCount: p.veins.length, veinMeshes: p.veinMeshes.length, veinRadii: p.veins.map(v => v.thickness), topRoughness: p.topMaterial.roughness, sideRoughness: p.edgeMaterial.roughness, radius: p.config.platformRadius, height: p.config.platformHeight, groupY: p.position.y };
      })()
    }));
    await page.waitForTimeout(2000);
    await capture('orbits-settled-2s.png');
    const after = await page.evaluate(() => ({
      stats: sepidTooth.getStats(),
      rotations: sepidTooth.orbits.entries.map(({ group }) => group.rotation.toArray().slice(0, 3)),
      particles: sepidTooth.orbits.entries.flatMap(({ particles }) => particles.map(p => ({ family: p.colorFamily, phase: p.phase, speed: p.speed, position: p.position.toArray(), radius: p.children[0].geometry.parameters.radius, color: p.children[0].material.color.getHexString(), roughness: p.children[0].material.roughness, metalness: p.children[0].material.metalness, glow: p.glow.material.uniforms.uGlow.value }))),
      platform: (() => {
        const p = sepidTooth.platform;
        return { sideColor: p.edgeMaterial.color.getHexString(), topColor: p.topMaterial.color.getHexString(), goldRimColor: p.goldRimMaterial.color.getHexString(), veinColor: p.veinMaterial.color.getHexString(), veinCount: p.veins.length, veinMeshes: p.veinMeshes.length, veinRadii: p.veins.map(v => v.thickness), topRoughness: p.topMaterial.roughness, sideRoughness: p.edgeMaterial.roughness, radius: p.config.platformRadius, height: p.config.platformHeight, groupY: p.position.y };
      })()
    }));
    const maxDelta = Math.max(...before.rotations.flatMap((r, i) => r.map((v, j) => Math.abs(v - after.rotations[i][j]))));
    const familyCounts = before.particles.reduce((counts, p) => (counts[p.family] = (counts[p.family] || 0) + 1, counts), {});
    assert.deepEqual(familyCounts, { gold: 5, pearl: 2, ice: 1 }, 'default 8 particles use nearest whole-particle 70/20/10 distribution');
    assert(before.particles.every(p => p.roughness <= .17 && p.glow <= .098), 'orb finish/glow should stay polished and restrained');
    assert.deepEqual(before.particles.map(({ family, phase, speed, color }) => ({ family, phase, speed, color })), after.particles.map(({ family, phase, speed, color }) => ({ family, phase, speed, color })), 'orb palette, phase, and speed remain stable');
    assert.notDeepEqual(before.particles.map(p => p.position), after.particles.map(p => p.position), 'orbs should keep moving on their existing paths');
    const goldAreaRatio = before.particles.filter(p => p.family === 'gold').reduce((sum, p) => sum + p.radius * p.radius, 0) / before.particles.reduce((sum, p) => sum + p.radius * p.radius, 0);
    assert(goldAreaRatio > .68 && goldAreaRatio < .75, `gold sphere area should be close to 70%, got ${goldAreaRatio}`);
    assert.equal(before.platform.sideColor, '0d2b50', 'platform side should use the requested deep navy');
    assert.equal(before.platform.topColor, '174775', 'platform top should use the specified reflected navy tone');
    assert.equal(before.platform.goldRimColor, 'd6b15e', 'top edge should retain the champagne-gold ring');
    assert.equal(before.platform.veinColor, 'd6b15e', 'gold veins should match the brand gold');
    assert(before.platform.veinCount >= 10 && before.platform.veinRadii.some(r => r >= .007), 'organic gold veins should be visible at mobile scale');
    assert(before.platform.veinMeshes <= 2, 'vein geometry should be merged by finish to keep draw calls low');
    assert(before.platform.radius >= 2 && before.platform.height >= .3 && before.platform.topRoughness <= .22, 'the podium should remain wide, low, and polished');
    assert(maxDelta < 1e-10, `orbit group rotations drifted: ${maxDelta}`);
    assert(before.stats.ready && after.stats.ready);
    assert(before.stats.renderedFrames > 0 && after.stats.renderedFrames > before.stats.renderedFrames);
    assert.deepEqual(errors, []);
    const report = { browser: 'Chromium/WebGL', before, after, maxOrbitRotationDelta: maxDelta, consoleErrors: errors, screenshots: ['test-artifacts/orbits-settled-0.png', 'test-artifacts/orbits-settled-2s.png'] };
    require('node:fs').writeFileSync(path.join(ROOT, 'test-artifacts/orbits-results.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify(report, null, 2));
  } finally { await browser?.close(); server.kill('SIGTERM'); }
})().catch(error => { console.error(error); process.exit(1); });
